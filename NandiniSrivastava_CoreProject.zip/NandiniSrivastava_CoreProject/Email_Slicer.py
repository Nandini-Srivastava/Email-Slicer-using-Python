def email_slicer(email):
    if '@' not in email:
        return "Invalid email address. Please include '@'."
    username, domain = email.split('@')
    return username, domain

def slicer():
    print("Welcome to the Email Slicer!")
    email = input("Please enter your email address: ")

    # Get the sliced parts
    result = email_slicer(email)

    # Check if the result is a tuple (valid email)
    if isinstance(result, tuple):
        username, domain_name = result
        print(f"Username: {username}")
        print(f"Domain: {domain_name}")
    else:
        print(result)


if __name__ == "__main__":
    slicer()